# Studio Dylan — vista estática para el cliente

Esta copia conserva la identidad visual y los servicios de la web original. Funciona sin Node.js, backend ni base de datos.

## Ver en esta computadora

Abrir `dist/index.html` en el navegador. También se puede servir `dist` con cualquier servidor estático.

## Publicar gratis en Render

1. Subir esta carpeta a un repositorio de GitHub (incluir `dist`, `render.yaml` y este archivo).
2. Iniciar sesión en https://dashboard.render.com y elegir **New → Static Site**.
3. Conectar ese repositorio y elegir su rama principal.
4. Poner **Build Command** en `true` (no hay nada que compilar) y **Publish Directory** en `dist`.
5. Crear el sitio estático. Compartir la dirección HTTPS `onrender.com` que Render entregue al finalizar.

También se incluye `render.yaml` para configurar el sitio con un Blueprint.

## Qué muestra

- Marca, presentación, imagen de perfil y tres servicios con su contenido original.
- Menú adaptable a celular y recorrido de día → horario → servicio y datos → confirmación.
- Cinco próximos días de atención, siempre disponibles para probar.
- Confirmación claramente identificada como demostración y botón **Reiniciar prueba**.

## Cómo funciona la prueba

No crea reservas reales. Los horarios de prueba solo cambian en memoria durante la visita y se reinician al recargar. No envía ni guarda nombres o teléfonos. No incluye el panel administrador, clientes, agenda privada, contraseñas ni enlaces de calendario.

El proyecto original permanece intacto. Para cambiar textos y servicios de esta copia, editar `dist/content.js`.
